<?php

	$con = new mysqli("localhost" , "root" , "" , "feedback" );
	
	if($con -> connect_error)
	{
		
		die("connection faild" . connect_error);
		
		
	}

	else
	{
		echo "<script> alert ('connected successfully') </script>";
	}
	
?>