<?php 
class album{
 var $albumid;
 var $albumname;
 var $albumprice;
 
}
 ?> 