function myFunction1() {
	alert("Everyone can see your name and photo. Developers can also see your country and device information (such as language , model and OS version) and may use this information to respond to you.");
	}
	
		
		
function myFunction() {
	alert("Thank you for sharing");
	}
	